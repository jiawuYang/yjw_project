cmake -B build &&\
cmake --build build
scp build/ats zl@192.168.3.12:/home/zl/jiakai