/**
 * Copyright (c) 2023 Tonly Technology Co., Ltd.,
 * All rights reserved.
 */

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#define SERVER_PORT 60001

int ChnUdpInit(void);
int ChnStdInInit(void);

#ifdef __cplusplus
}
#endif
